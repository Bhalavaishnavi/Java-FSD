import { Component, OnInit } from '@angular/core';
import { FormGroup } from '@angular/forms';

@Component({
  selector: 'app-attendancedashboard',
  templateUrl: './attendancedashboard.component.html',
  styleUrls: ['./attendancedashboard.component.css']
})
export class AttendancedashboardComponent implements OnInit {
  formvalue !: FormGroup;
  formbuilder: any;
  constructor() { }

  ngOnInit(): void {
    this.formvalue = this.formbuilder.group({
      id : [],
      employeeid : [''],
      name : [''],
      startdate : [''],
      enddate : [''],
      date: ['']
    })
  }

}
