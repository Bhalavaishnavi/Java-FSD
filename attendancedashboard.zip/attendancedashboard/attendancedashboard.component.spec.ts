import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AttendancedashboardComponent } from './attendancedashboard.component';

describe('AttendancedashboardComponent', () => {
  let component: AttendancedashboardComponent;
  let fixture: ComponentFixture<AttendancedashboardComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AttendancedashboardComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AttendancedashboardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
